menu = {"menu": {
  "id": "file",
  "value": "File",
  "popup": {
    "menuitem": [
      {"value": "New", "onclick": "CreateNewDoc()"},
      {"value": "Open", "onclick": "OpenDoc()"},
      {"value": "Close", "onclick": "CloseDoc()"}
    ]
  }
}}
  
  
 

first = menu["menu"]["popup"]["menuitem"][0]  #{"value": "New", "onclick": "CreateNewDoc()"}
second = menu["menu"]["popup"]["menuitem"][1]
third = menu["menu"]["popup"]["menuitem"][2]

print(first["value"])
print(second["value"])
print(third["value"])