
import csv
#Write a Python program to read realestate.csv and
#display the count of an individual city.

cities = list()
with open("realestate.csv","r") as fobj:
    header = fobj.readline()
    # converting file object (fobj)   to the csv object ( reader)
    reader = csv.reader(fobj)
    for line in reader:
        city = line[1]
        cities.append(city)

        
## display all unique cityname
for city in set(cities):
    print(city.ljust(15) ,cities.count(city))

