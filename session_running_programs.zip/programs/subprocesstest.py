import subprocess

# invoking system commands in python
output = subprocess.getoutput("")
print(output)


# 2nd method  ## outdated
os.system("dir")