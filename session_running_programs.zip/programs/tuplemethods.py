

atup = (10,20)

print(atup.count(10))

print(atup.index(2000))