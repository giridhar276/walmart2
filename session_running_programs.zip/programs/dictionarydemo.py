

# dictionary demo
book = { "chap1":10  ,"chap2":20 , "chap3":30 , "chap1":1000}
print(book)

## accessing individual value
print(book["chap1"])  # 10
print(book["chap2"])  # 20


values = {1:2,3:4,5:6}

info  =  {"first":[10,20],"second":(45,54)}
print(info["first"][0])  # 10

book = {"chap1":{"charles":25} }
print(book["chap1"])
