urllib3 #

import requests
from bs4 import BeautifulSoup

url ="https://www.google.com"


response = requests.get(url)
if response.status_code == 200 :
    soup = BeautifulSoup(response.text, 'html.parser')
    for link in soup.find_all('a'):
        print(link.get('href'))

elif response.status_code == 401 :
    print("Client side error")

elif response.status_code == 501 :
    print("Server side issue")
    
    