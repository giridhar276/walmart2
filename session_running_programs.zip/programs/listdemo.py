

# list demo
alist =[10,20,30]
blist = ["machine learning","spark","scala"]
clist = [10,20,4,434.32,"unix"]


alist[0] = 'unix'
print("After modifying :", alist)



print("elements are :", alist)
print("Languages are :", blist)
print(alist,blist,clist)

# + is the concatenation operator
finallist = alist + blist + clist
print(finallist)
# * is the repetition operator
print(alist * 4)


name = "python"
lang = "programming"
out = name  + " " + lang
print(out)
print(name * 2)

