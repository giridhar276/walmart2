

name = "python"
print(len(name))

alist = [10,20,30,_]
print(len(alist))

atup = (20,30,40)
print(len(atup))