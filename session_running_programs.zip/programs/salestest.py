import csv
country_state=dict()
with open("sales.csv","r") as fobj: 
    header=fobj.readline()
    reader=csv.reader(fobj)
    for line in reader :
        country=line[7]
        state=line[6]
        if country not in country_state:
            country_state[country]=set(state)
        else:
            print(type(country_state[country]))
            #country_state[country] = country_state[country].add(state)
          
 
    for (key,value) in  country_state:
        print(key,value)
