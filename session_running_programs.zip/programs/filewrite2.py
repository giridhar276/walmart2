'''
write a program to capture your name from keyboard and
write the output to the file.
'''

name = input("Enter any string :")
with open("yourname.txt","w") as fobj:
    fobj.write(name + "\n")




'''
write a program to write all the all numbers from 100 to 50 
to the file line by line.
'''

with open("numbers.txt","a") as fobj:
    for val in range(100,50,-1):
        fobj.write(str(val)  + "\n")  # error
       