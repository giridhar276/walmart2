import fileinput 
  
filename = "realestate.csv"
  
with fileinput.FileInput(filename, inplace = True) as f: 
    for line in f:
            line = line.replace("SACRAMENTO", "HYDERABAD")
            print(line,end='')
