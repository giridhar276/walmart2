



with open("realestate.csv","r") as fobj:
    print(fobj.readline())
    print(fobj.readline())

