

class Scope:
    def __init__(self):
        self.public = "I am public"
        self._protected = "I am protected"
        self.__private= "I am private"
        print(self.__private)


obj1  = Scope()
print(obj1.public)
print(obj1._protected)
print(obj1.__private)

