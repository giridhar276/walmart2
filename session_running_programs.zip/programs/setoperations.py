
##### 

aset = {10,20,30,30,10,10,20,20}
bset = {30,40,50,40,30,20,20,20,20}

# unique operation
print(aset | bset)
print(aset.union(bset))

# intersection operation
print(aset & bset)
print(aset.intersection(bset))

print(aset - bset)
print(aset.difference(bset))

aset.add(10)
print(aset)



