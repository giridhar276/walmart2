

import pandas as pd

df = pd.read_csv("IPL.csv")

print(df['PLAYER NAME'])