

#  * indicates tuple
def display(*data):
    for item in data:
        print(item)
    
    
display(10,20,30,40)



## ** is dictionary

def display(**book):
    for key,value in book.items():
        print(key,value)
        if key == value :

display(chap1= 10 , chap2 =20)




def display(first, *rest):
    print(first) #10
    print(rest)  #
    
display(10,20,30,40,50)
