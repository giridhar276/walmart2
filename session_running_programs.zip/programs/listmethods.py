alist = [10,20,30,40]
alist.append(50)
alist.append(60)
print("After appending :", alist)
alist.append({"chap1":10, "chap2":20})
print("After appending :", alist)

#alist.clear()  # removing all the elements of the list
print(alist)


alist = [10,20,30,40]
alist.append([50,60,70,80])
print(alist)
print("After appending :", alist)

alist = [10,20,30,40,10]
alist.extend([50,60,70,30,30,30,30,30,80])
print("After extending :", alist)  

print("count of 10 is  :", alist.count(10))
######alist.insert(where to list , what to list)
alist.insert(0,5)


print("After inserting :", alist)
alist.insert(3,25)
print("After inserting :", alist)
alist.pop()   # will remove the last element by default
print(alist)
alist.pop(2)   # remove value at index 0
print(alist)
alist.remove(30)   # removing the value directly
                   # No concept of indexing, we directly remove the value
print(alist)
alist = [50,434,534235,34354532,2,3,546]
alist.reverse()   # reverse happens in place( to the actual list)
print(alist)

alist.sort()
print(alist)





