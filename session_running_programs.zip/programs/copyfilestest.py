import shutil
import os
source = "D:\\walmart2\\programs\\source"
destination = "D:\\trainings\\walmart2\\programs\\destination"
# change the directory to the source
#os.chdir(source)

for file in os.listdir(source):
    print(file)
    shutil.copy( file,destination)
    print(file, "copied to " , destination)



source = "D:\\walmart2\\programs\\source"    #OR
source = "D:/walmart2/programs/source"       #OR
source = r"D:\walmart2\programs\source"      #OR
