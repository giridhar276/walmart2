#write a program to display all the files and directories from the current directory line by line
import os
for file in os.listdir():
    print(file)
    
# from C:
for file in os.listdir("C:\\") :
    print(file)
    
#write a programt to display today's timestamp
import time
print(time.time())   # epoch time
print(time.strftime("%d %b %Y"))
import datetime
print(datetime.datetime.now())
print(datetime.date.today())

### creating 100 directories
for val in range(1,11):
    os.mkdir("dir" + str(val))
    
## display ONLY .py files and its size
for file in os.listdir():
    if file.endswith(".py"):
        size = os.path.getsize(file)
        print(file.ljust(15), size ,"bytes")
        
    
## create file with today's timestamp
filename = time.strftime("%d_%b_%Y.log")  #
fobj = open(filename,"w")
fobj.close()


