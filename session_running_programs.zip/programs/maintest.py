


def display():
    print("Inside def")

def display1():
    print("Inside def")
    
def display2():
    print("Inside def")    


# If this program is executed as standalone program 
# then only the condition comes true
if __name__ == "__main__":   # this condition will be always True
    display()
    
    
    
