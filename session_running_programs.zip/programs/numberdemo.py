
# number
val = 10
print(val)
print("number is :", val)

aval = 34.43
print(aval)


## string demo
name  ="python programming"
aname = 'machine learning'
bname = """deeplearning"""

print(name)
print("language is :", aname)
print(name,aname,bname)