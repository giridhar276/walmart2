def add(first,second):
    total = first + second
    return total

total = add(10,20)
print(total)


