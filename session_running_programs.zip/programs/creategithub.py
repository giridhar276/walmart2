   
import requests
import json

server = "https://api.github.com"
url = server + "/gists"
user = "giridhar276"

print("checking ", url, "using user:", user)

local_file = "realestate.csv"
with open(local_file) as fh:
    # reading the file in string format
    mydata = fh.read()
files = {
    "description": "rest api - giri testing",
    "public": "true",
    "user" : user,
    "files": {
    local_file: {
    "content": mydata
        }
      }
}
r1 = requests.post(url, data=json.dumps(files), auth=('giridhar276','2fac3fd77886a8f6fceb933fdd822b76eb0fb7bc'))
print(r1.json())
