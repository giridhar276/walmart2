import pickle

example_dict = {1:"6",2:"2",3:"f"}

fobj = open("dict.pickle","wb")
pickle.dump(example_dict, fobj)
fobj.close()


# deserialization
fread = open("dict.pickle","rb")
example_dict = pickle.load(fread)
print(example_dict)


