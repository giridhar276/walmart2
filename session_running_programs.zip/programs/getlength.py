


countrydict = dict()

with open("sales.csv","r") as fobj:
    for line in fobj:
        line = line.split(",")
        country = line[7]
        state = line[6]
        if country not in countrydict:
            print(state)
            countrydict[country].append(state)

print(country)