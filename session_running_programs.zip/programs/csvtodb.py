import pymysql
import csv   
def main():
    try:
        with pymysql.connect(host="localhost",port=3306,user='root',password='india@123') as db:
            
            with open("realestate.csv") as fobj:
                reader = csv.reader(fobj)
                for line in reader:
                    street = line[0]
                    city  = line[1]
                
                    query = "insert into walmart.realestate values('{}','{}')".format(street,city)
                    db.execute(query)
                    print(db.rowcount , "row inserted")
            
    except pymysql.OperationalError as err:
        print(err)

    
if __name__ == "__main__":
    output = main() 
    print(output)
    
    

