a=10
a = 30
#print(a)
a=a*2
a=a+10
print(a)
