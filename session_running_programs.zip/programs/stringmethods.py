
name = "python"

print(name[0])
#name[0] = "J"
#print("After modifying :", name)

print(name.capitalize())

print(name.lower())
output =  "hello" + "hi"
print(name.upper())
lang = "python programming"
print(lang.count("p"))  # 1

print(name.isupper())
print(name.islower())
print(lang.isalpha())
print(lang.split(" "))  # will be converted to list
print(lang.replace("python","scala"))
new = lang.replace("python","scala")
print(new)
print(lang.center(40))
print(lang.center(40,"*"))
print(lang.encode())
#print(lang.encode('utf-16'))
#print(lang.encode('utf-32'))
print(lang.startswith("z"))   # False
print(lang.startswith("p"))
print(lang.endswith("g"))
name = "python  "
print(len(name))
name = name.strip()  # will remove whitespaces at both the ends
print(len(name))
name = name.lstrip()
name = name.rstrip()


name = "I love {} and {}"   # skeleton  or template
print(name.format("hadoop","spark"))
print(name.format(1,2))

name = "I love {0} and {1}"   # skeleton  or template
print(name.format("hadoop","spark"))
print(name.format(1,2))

name = "I love {1} and {0}"   # skeleton  or template
print(name.format("hadoop","spark"))
print(name.format(1,2))






















