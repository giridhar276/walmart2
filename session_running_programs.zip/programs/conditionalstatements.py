
# simple if
lang = input("Enter any name :")

if lang == "python" :
    print("Its python")
    
# if-else

if lang == "python":
    print("Its python")
else:
    print("Its is some other diff language")
    
    

# if-elif-elif... else
if lang == "python":
    print("Its python")
elif lang == "spark":
    print("spark")
elif lang == "scala":
    print("scala")
else:
    print("some other language")    
    