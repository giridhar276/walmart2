import pymysql

# keyword arguments

with pymysql.connect(host = 'localhost',port = 3306,root = 'root',passowrd = 'india@123',database = 'walmart') as db:


    query="Select * from realestate"

    db.execute(query)

    for record in db.fetchall():
        print(record)
