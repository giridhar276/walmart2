import pandas

# reading file line by line     
with open("numbers.txt") as fobj:
    for line in fobj:
        # will remove the white space at the end of the string
        line = line.strip()
        output = line.split(",")
        # display
        print(output)
        
# using read()  ---------------> string
# Generally not suggested
# Just like  ctrl + A  ( copy the whole content)    and ctrl + v
with open("numbers.txt","r",buffering= -1) as fobj:
    print(fobj.read())       
    
# using readlines()
with open("numbers.txt","r") as fobj:
    print(fobj.readlines())
    for line in fobj.readlines():
        print(line)
        
    
# using csv library
# each line will be automatically converted to the list
import csv
with open("numbers.txt","r") as fobj:
    # converting file object (fobj)   to the csv object ( reader)
    reader = csv.reader(fobj)
    for line in reader:
        print(line)


