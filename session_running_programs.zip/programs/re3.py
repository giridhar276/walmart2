
import re

string = "python programming language"

if re.search("pyt+hon",string):
    print("String exists")
else:
    print("doesn't exist")