

class Employee:
    def getName(self,name = "default"):
        #creating local variables within the class
        self.name = name
        print("Employeename :", self.name)
    def displayName(self):
        print(self.name)
        
# objet initilzation
emp1 = Employee()
emp1.getName()
emp1.displayName()
emp2 = Employee()
emp2.getName("sarma")
emp2.displayName()