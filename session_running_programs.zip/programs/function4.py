



# default arguments
def display(first = 0,second = 0,third= 0):
    print(first,second,third)
    
display()
display(10)
display(10,20)
display(10,20,30)