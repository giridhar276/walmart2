#Write a Python program to read realestate.csv and display all the 
#UNIQUE cities and the count of unique cities.
############### Method 1
import csv
uniqueCities = set()
with open("realestate.csv","r") as fobj:
    header = fobj.readline()
    # converting file object (fobj)   to the csv object ( reader)
    reader = csv.reader(fobj)
    for line in reader:
        uniqueCities.add(line[1])
        
## display all unique cityname
for city in uniqueCities:
    print(city)
print("Total no. of cities :", len(uniqueCities))


# METHOD 2
uniqueCities = dict()
with open("realestate.csv","r") as fobj:
    header = fobj.readline()
    # converting file object (fobj)   to the csv object ( reader)
    reader = csv.reader(fobj)
    for line in reader:       # line = ['3526 HIGH ST','SACRAMENTO','95838','CA']
        # creating key:value pairs like   {SARCAMENTO:1 , RIO LINDA:1 ......}
        uniqueCities[city] = 1
        
## display all unique cityname
for city in uniqueCities.keys():
    print(city)
print("Total no. of cities :", len(uniqueCities))
