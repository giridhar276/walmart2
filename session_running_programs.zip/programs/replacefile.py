import csv
import sys
uniqueCities = dict()
try:
    filename = input("Enter filename :")
    with open(filename,"r") as fobj:
        header = fobj.readline()
        # converting file object (fobj)   to the csv object ( reader)
        reader = csv.reader(fobj)
        for line in reader:
            if "SACRAMENTO" in line:
                line[1] = "BANG"
            # reconverting back to the string
            # list ----> string
            lineStr = "".join(line)
            print(lineStr)
    output = 3 + "hello"
except (FileNotFoundError,TypeError,ValueError,KeyError) as err:
    print("custom error message : FIle not found")
    print(err)   
except Exception as err:
    print("Unknown exception")
    print(sys.exc_info())
    print(err)   
else:
    print("processing the data")
finally:
    print("End of the processing")