# write operation
fobj  = open("abc.txt","w")
fobj.write("first line")
fobj.write("second line")
fobj.write("third line")
fobj.close()


# with keyword 
# context manager
# closing the file is not required
# file will be closed automatically when it comes out of indentation
with open("abcd.txt","w") as fobj:
    fobj.write("first line\n")

    fobj.write("second line\n")
    
# database programming
# networking : ssh sftp 



