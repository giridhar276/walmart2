




with open("realestate.csv","r") as fread:
    with open("backup.csv","w") as fwrite:
        for line in fread:
            line = line.strip()
            line = line.replace("SACRAMENTO","BANGALORE")
            fwrite.write(line)

os.unlink("realestate.csv")




