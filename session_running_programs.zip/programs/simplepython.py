
print("python programming")
