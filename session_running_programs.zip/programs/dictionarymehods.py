adict = {"chap1":10 , "chap2":20 , "chap3":30}

print(list(adict.keys()))   # display all the keys
print(tuple(adict.values()))


print(adict.items())  # list of tuples

# deleting key-value pair
adict.pop("chap1")
print("After removing :", adict)
adict.pop("chap2")
print("After removing :", adict)

adict = {"chap1":10 , "chap2":20 , "chap3":30}
adict.popitem()   # will randomly remove key:value
print("After popitem :", adict)
adict.popitem()
print("After popitem :", adict)
adict.popitem()
print("After popitem :", adict)
adict = {"chap1":10 , "chap2":20 , "chap3":30}

bdict = {"chap4":40 ,"chap5":50}
# adding all the bdict elements to adict
adict.update(bdict)
print(adict)

# B to A
bdict.update(adict)
print(bdict)

print(adict.get("chap1000"))   # None since not existing
print(adict.get("chap2"))

print(adict.fromkeys("chap1"))  # converting single char of key ---> dictionary













