


if 1 < 2 :
    raise(ValueError("Inequality"))