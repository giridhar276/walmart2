
##### converting tuple --------> list
atup = (10,20,30,40)

#atup[0]= 1000
#print("After modifying :", atup)

data = list(atup)   # converted to list
data[0]  = 10000
atup = tuple(data)  #reconverted back to tuple
print("After modifying :", atup)

#### converting string ----------> list
name= "python"
alist = list(name)  # string--> list
output = "".join(alist)
print(output)

#print(tuple(name))


