## default arguments


def add(first = 0,second = 0 ,third = 0):
    total = first + second
    return total

total = add()
print(total)

total = add(10)
print(total)

total = add(10,20)
print(total)


total = add(10,20,30)
print(total)
