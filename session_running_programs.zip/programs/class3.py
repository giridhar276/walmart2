class Employee:
    # constructor
    def __init__(self,name= "defualt"):
        #creating local variables within the class
        self.name = name
        print("Employeename :", self.name)
    def displayName(self):
        print(self.name)
        
# objet initilzation
emp1 = Employee("ram")
emp1.displayName()

emp2 = Employee("sharma")
emp2.displayName()

emp3 = Employee()
emp3.displayName()
