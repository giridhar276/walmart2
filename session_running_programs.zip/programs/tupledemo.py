# -*- coding: utf-8 -*-
"""
Created on Wed May  6 10:53:04 2020

@author: gsripath
"""

atup = (10,20,30)
btup = ("scala","spark","hadoop")
ctup = (34,"bigdata","ML")

print("tuple elements are :", atup)
print("languages :", btup)
print(ctup)


atup[0] = 'linux'
print("After modifying :", atup)``