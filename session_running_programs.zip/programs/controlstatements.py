

## displaying numbers from 1 to 9 
for val in range(1,10):
    print(val)
    
## iterating string
for char in "python":
    print(char)

# iterating list
alist = [10,20,30]
for val in alist:
    print(val)
    
# iterating tuple
atup = ("unix","spark","pig")
for val in atup:
    print(val)

# iterating dictionary
adict = {"chap1":10 , "chap2":20 }
for key,value in adict.items():    
    print(key,value)                
    
# reading only keys and displaying values
for key in adict.keys():
    print(key,adict[key])
    
    
    
    