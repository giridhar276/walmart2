aset = {10,10,10,20,30}

print(aset)

bset = {30,40,50,50,50,50,50,50,50,50}
print(bset)

print(aset & bset)   # intersection
print(aset | bset)   # union
print(aset - bset)   # difference