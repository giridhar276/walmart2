

# function block
def add(val):
    return val + 5

# calling function
total = add(10)
print(total)


# lambda functions ( inline functions in C++ )
# functioname = lambda variables : expression

add = lambda x : x+ 5

total = add(10)
print(total)


getupper = lambda x :x.upper()
print(getupper("python"))


#1
alist =[10,20,30,40]
#output: [15,25,35,45]
blist = []
for val in alist:
    blist.append(val + 5)
    
 #2   
alist =[10,20,30,40]
def increment(x):
    return x + 5
print(list(map( increment ,alist)))   

#3
alist =[10,20,30,40]
increment = lambda x : x + 5
print(list(map( increment ,alist)))   

 #4   map()
alist =[10,20,30,40]
print(list(map( lambda x : x + 5 ,alist)))   

alist = [34,3,3,46,43,4354543,3,345]
print(list(filter( lambda x : x%2 == 0 ,alist))) 
print(list(filter( lambda x : x%2  ,alist)))

alist = ["unix","python","c","scala"]
print(list(map( lambda x : len(x) ,alist)))

adict = {"chap1":10 ,"chap2":20}   
  


   




    
    
    
    
    
    
    
    














