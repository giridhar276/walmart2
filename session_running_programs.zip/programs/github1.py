

import requests
import json

url = "https://api.github.com"
username = 'giridhar276'
password = "2fac3fd77886a8f6fceb933fdd822b76eb0fb7bc"
response = requests.get(url, auth= (username,password)  )

print(response.text)
 
data =json.loads(response.text)

for key,value in data.items():
    print(key.ljust(20),value)